const API = import.meta.env.VITE_API_URL || '';
export async function request(path, options={}) {
  const token = localStorage.getItem('clashclip_token');
  const headers = {...(options.body instanceof FormData ? {} : {'Content-Type':'application/json'}), ...(options.headers||{})};
  if(token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API}/api${path}`, {...options, headers});
  const data = await response.json().catch(()=>({error:'Unexpected server response'}));
  if(!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
export const mediaUrl = (key) => key || '';