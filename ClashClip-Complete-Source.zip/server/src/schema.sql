CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), email TEXT UNIQUE NOT NULL,
 handle TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS battles (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), creator_a UUID NOT NULL REFERENCES users(id),
 creator_b UUID REFERENCES users(id), caption VARCHAR(180) NOT NULL, category VARCHAR(40) NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','active','completed','removed')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS votes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), battle_id UUID NOT NULL REFERENCES battles(id) ON DELETE CASCADE,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, side CHAR(1) NOT NULL CHECK(side IN ('A','B')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(battle_id,user_id)
);
CREATE TABLE IF NOT EXISTS videos (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), owner_id UUID NOT NULL REFERENCES users(id),
 battle_id UUID REFERENCES battles(id), object_key TEXT NOT NULL, playback_url TEXT,
 caption VARCHAR(180), duration_seconds INTEGER CHECK(duration_seconds BETWEEN 1 AND 60),
 status TEXT NOT NULL DEFAULT 'processing', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS live_rooms (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), host_id UUID NOT NULL REFERENCES users(id),
 room_name TEXT UNIQUE NOT NULL, title VARCHAR(180) NOT NULL,
 status TEXT NOT NULL DEFAULT 'live' CHECK(status IN ('live','ended')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), ended_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS wallets (
 user_id UUID PRIMARY KEY REFERENCES users(id), balance_kobo BIGINT NOT NULL DEFAULT 0 CHECK(balance_kobo>=0),
 coins BIGINT NOT NULL DEFAULT 0 CHECK(coins>=0), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS ledger (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id),
 transaction_ref TEXT NOT NULL, entry_type TEXT NOT NULL, amount_kobo BIGINT NOT NULL,
 description TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(transaction_ref,user_id,entry_type)
);
CREATE TABLE IF NOT EXISTS payments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id),
 provider TEXT NOT NULL, provider_reference TEXT UNIQUE NOT NULL, amount_kobo BIGINT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', coins BIGINT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS gifts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), sender_id UUID NOT NULL REFERENCES users(id),
 creator_id UUID NOT NULL REFERENCES users(id), room_id UUID REFERENCES live_rooms(id),
 gift_type TEXT NOT NULL, coin_value BIGINT NOT NULL, platform_fee BIGINT NOT NULL,
 creator_credit BIGINT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS battles_created_idx ON battles(created_at DESC);
CREATE INDEX IF NOT EXISTS live_status_idx ON live_rooms(status);
CREATE INDEX IF NOT EXISTS ledger_user_idx ON ledger(user_id,created_at DESC);
