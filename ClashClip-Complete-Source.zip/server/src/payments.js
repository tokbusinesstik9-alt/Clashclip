import crypto from 'node:crypto';
import {query,pool} from './db.js';
export async function initializePaystack(userId,amountNaira){
 if(!process.env.PAYSTACK_SECRET_KEY) throw new Error('Paystack is not configured.');
 if(!Number.isInteger(amountNaira)||amountNaira<100) throw new Error('Minimum purchase is ₦100.');
 const ref=`cc_${crypto.randomUUID()}`,amountKobo=amountNaira*100,coins=amountNaira;
 await query('INSERT INTO payments(user_id,provider,provider_reference,amount_kobo,coins) VALUES($1,$2,$3,$4,$5)',[userId,'paystack',ref,amountKobo,coins]);
 const r=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({email:(await query('SELECT email FROM users WHERE id=$1',[userId])).rows[0].email,amount:amountKobo,reference:ref,callback_url:process.env.CLIENT_ORIGIN})});
 const d=await r.json();if(!r.ok||!d.status)throw new Error(d.message||'Could not initialize payment');return {authorization_url:d.data.authorization_url,reference:ref};
}
export async function handlePaystackWebhook(req,res){
 const signature=req.headers['x-paystack-signature'];const expected=crypto.createHmac('sha512',process.env.PAYSTACK_SECRET_KEY||'').update(req.rawBody).digest('hex');
 if(!signature||!crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))return res.sendStatus(401);
 const event=req.body;if(event.event==='charge.success'){
  const ref=event.data.reference;const client=await pool.connect();
  try{await client.query('BEGIN');const p=await client.query('SELECT * FROM payments WHERE provider_reference=$1 FOR UPDATE',[ref]);
   if(p.rowCount&&p.rows[0].status!=='success'){const row=p.rows[0];await client.query("UPDATE payments SET status='success' WHERE id=$1",[row.id]);await client.query('INSERT INTO wallets(user_id,coins) VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET coins=wallets.coins+EXCLUDED.coins,updated_at=now()',[row.user_id,row.coins]);await client.query('INSERT INTO ledger(user_id,transaction_ref,entry_type,amount_kobo,description) VALUES($1,$2,$3,$4,$5)',[row.user_id,ref,'coin_purchase',row.amount_kobo,'Coin purchase']);}
   await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
 }res.sendStatus(200);
}