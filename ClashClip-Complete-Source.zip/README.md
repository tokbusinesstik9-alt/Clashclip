# ClashClip

ClashClip is a production-oriented short-video battle and live-streaming platform starter. It contains no seeded/demo users, videos, products, battles, gifts, or transactions. All feed content comes from the database.

## Included
- Email/password registration and login with hashed passwords and JWT sessions
- PostgreSQL schema for users, videos, battles, votes, live rooms, gifts, wallet ledger and transactions
- Video upload using S3-compatible object storage (AWS S3, Cloudflare R2, or compatible)
- Battle creation and voting with one vote per user per battle
- Live room creation and LiveKit token generation
- Coin purchase checkout via Paystack and verified webhook handling
- Gift sending with atomic 90/10 creator/platform ledger split
- Transaction fee helper: 10% platform commission, applied once per eligible transaction
- User profiles, feed, battle detail, wallet and leaderboard APIs
- Responsive React website
- Render deployment blueprint

## Important production setup
Real video delivery, live streaming and payments require credentials from the providers you choose. The app intentionally does not pretend those integrations work without credentials. Never commit `.env` secrets.

## Requirements
- Node.js 20+
- PostgreSQL 15+
- Paystack account and secret key for coin checkout
- S3-compatible bucket for video uploads
- LiveKit project for live streaming

## Local setup
1. Copy `.env.example` to `server/.env` and fill every required value.
2. Create a PostgreSQL database and run `npm run db:migrate`.
3. Install dependencies: `npm install`.
4. Start both apps: `npm run dev`.
5. Open `http://localhost:5173`.

The API runs on `http://localhost:4000`.

## Render
Use the included `render.yaml` as a starting point. Create the PostgreSQL database and web service in Render. Add the environment variables listed in `server/.env.example`. Set the web service root directory to the repository root, build command to `npm install && npm run build`, and start command to `npm start`.

## Commission rules
The backend uses a 10% platform commission for gift payouts. A ₦1,000 eligible gift allocates ₦900 to the creator and ₦100 to the platform. Paystack processing fees, applicable taxes, refunds and chargebacks are separate. The webhook uses Paystack reference idempotency to prevent duplicate crediting. Do not advertise a payout as withdrawable until a compliant withdrawal provider and KYC process have been configured.

## Security and launch checklist
- Set long random JWT_SECRET and COOKIE_SECRET values.
- Configure HTTPS and exact CORS_ORIGIN.
- Configure Paystack webhook URL: `/api/payments/paystack/webhook`.
- Verify Paystack webhook signature; keep secret key server-side only.
- Configure S3 CORS, private upload credentials, file-size/type limits and lifecycle policies.
- Configure LiveKit URL/API key/secret.
- Add email verification, password reset, age policy, privacy policy, terms, moderation and reporting workflows before public launch.
- Configure backups, logging, rate limits, monitoring and a real content moderation process.
- Review local payment, tax, consumer-protection and child-safety requirements before launch.

This is an implementation foundation, not a claim that external provider accounts or production credentials have already been configured.